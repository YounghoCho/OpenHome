package com.worksmobile.openhome.status;

public enum ReturnStatus {
	SUCCESS
}
